import React from "react";

const Login: React.FC = () => {
  return <div>Login Page</div>;
};

export default Login;
