import React from "react";

const Tasks: React.FC = () => {
  return <div>Tasks Page</div>;
};

export default Tasks;
