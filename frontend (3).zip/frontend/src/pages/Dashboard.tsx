import React from "react";

const Dashboard: React.FC = () => {
  return <div>Dashboard Page</div>;
};

export default Dashboard;
